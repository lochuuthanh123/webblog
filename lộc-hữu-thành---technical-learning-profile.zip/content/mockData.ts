
import { Tag, Level, Activity, Profile, Project, ToolboxSnippet, Certification } from '../types';

export const profileData: Profile = {
  full_name: "Lộc Hữu Thành",
  school: "HUTECH – Đại học Công Nghệ TP.HCM",
  field: "An toàn thông tin & An ninh mạng",
  current_focus: "SOC / Blue Team / Network Security",
  bio: "Sinh viên chuyên ngành An toàn thông tin. Tập trung nghiên cứu về giám sát an ninh mạng (SOC), phân tích nhật ký hệ thống và ứng cứu sự cố. Ưu tiên các giải pháp mã nguồn mở và quy trình kỹ thuật thực tế.",
  tools: ["Wireshark", "Burp Suite", "Nmap", "Linux", "Suricata", "Wazuh"],
  interests: ["Log analysis", "Detection engineering", "Network traffic analysis", "Incident response"],
  verified_achievements: [
    "Top 99 vòng sơ khảo – Cuộc thi Sinh viên An ninh mạng 2025 (Bộ Công An)",
    "Top 3 cấp trường – Sinh viên An ninh mạng 2025"
  ],
  skills: [
    { name: "Log Analysis", value: 75 },
    { name: "Traffic Analysis", value: 80 },
    { name: "Incident Response", value: 60 },
    { name: "Malware Analysis", value: 45 },
    { name: "System Admin", value: 70 },
    { name: "Threat Hunting", value: 55 }
  ]
};

export const toolboxSnippets: ToolboxSnippet[] = [
  {
    title: "SSH Brute-force Detection (Wazuh)",
    tool: "Wazuh",
    description: "Rule tùy chỉnh phát hiện 10 lần login thất bại từ cùng một IP trong 2 phút.",
    code: `<rule id="100001" level="10">\n  <if_sid>5712</if_sid>\n  <match>Failed password</match>\n  <frequency>10</frequency>\n  <timeframe>120</timeframe>\n  <description>Possible SSH Brute-force Attack</description>\n</rule>`
  },
  {
    title: "Filter HTTP Data (Wireshark)",
    tool: "Wireshark",
    description: "Lọc các gói tin HTTP chứa dữ liệu nhạy cảm hoặc request lạ.",
    code: `http.request.method == "POST" && !(http.content_type contains "image")`
  }
];

export const activitiesData: Activity[] = [
  {
    slug: "2025-03-01-cyber-student-2025",
    date: "2025-03-01",
    title: "Vòng sơ khảo Sinh viên An toàn thông tin 2025",
    tags: [Tag.CTF, Tag.CERT],
    level: Level.INTERMEDIATE,
    tools_used: ["Linux", "Wireshark", "Burp Suite"],
    what_i_did: [
      "Giải quyết các thử thách Web Exploitation liên quan đến IDOR và Path Traversal",
      "Phân tích tệp PCAP trong mảng Forensics để tìm kiếm dấu hiệu exfiltration",
      "Sử dụng công cụ Reverse Engineering cơ bản để trích xuất flag từ binary"
    ],
    what_i_learned: [
      "Kỹ năng xử lý tình huống dưới áp lực thời gian thực",
      "Nhận diện nhanh các vector tấn công phổ biến trong môi trường CTF"
    ],
    verification: {
      id: "TEAM_LTH_2025_001",
      note: "Xác thực qua Dashboard cuộc thi"
    },
    next_step: "Tập trung sâu hơn vào mảng Binary Analysis và Pwn.",
    images: ["https://picsum.photos/seed/ctf1/1200/800", "https://picsum.photos/seed/ctf2/1200/800"]
  },
  {
    slug: "2025-02-20-wazuh-deployment-lab",
    date: "2025-02-20",
    title: "Triển khai giám sát tập trung với Wazuh SIEM",
    tags: [Tag.LAB],
    level: Level.INTERMEDIATE,
    tools_used: ["Wazuh", "Linux"],
    what_i_did: [
      "Cài đặt Wazuh Manager trên nền tảng Ubuntu Server 22.04 LTS",
      "Cấu hình Agent trên 02 máy ảo để đẩy log về Manager",
      "Thiết lập Rule tùy chỉnh để phát hiện brute-force attack qua SSH"
    ],
    what_i_learned: [
      "Cấu trúc và cách hoạt động của cơ chế lọc log qua bộ giải mã (Decoder)",
      "Cách tối ưu hóa tài nguyên phần cứng khi xử lý lượng log lớn"
    ],
    verification: {
      hash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      note: "Wazuh Alert ID: 1582930122.341"
    },
    next_step: "Tích hợp thêm Suricata để tăng cường khả năng IDS cho hệ thống.",
    images: ["https://picsum.photos/seed/wazuh1/1200/800"]
  }
];

export const projectsData: Project[] = [
  {
    slug: "soc-lab-network-traffic",
    title: "SOC Lab – Network Traffic Monitoring",
    tags: [Tag.PROJECT, Tag.LAB],
    tools: ["Suricata", "Wazuh", "Wireshark"],
    description: "Xây dựng hệ thống giám sát lưu lượng mạng tập trung, phân tích cảnh báo từ IDS và trực quan hóa dữ liệu sự kiện an ninh.",
    images: [
      "https://picsum.photos/seed/soc1/1200/800",
      "https://picsum.photos/seed/soc2/1200/800",
      "https://picsum.photos/seed/soc3/1200/800"
    ]
  }
];

export const certificationsData: Certification[] = [
  {
    slug: "isc2-certified-in-cybersecurity",
    title: "Certified in Cybersecurity (CC)",
    issuer: "ISC2",
    date: "2024-12-15",
    verification_url: "https://www.credly.com",
    description: "Chứng chỉ cơ bản về nguyên lý bảo mật, điều khiển truy cập, an ninh mạng và hoạt động bảo mật.",
    image: "https://picsum.photos/seed/cert1/600/400"
  },
  {
    slug: "thm-soc-level-1",
    title: "SOC Level 1 Path",
    issuer: "TryHackMe",
    date: "2024-10-10",
    verification_url: "https://tryhackme.com",
    description: "Hoàn thành lộ trình đào tạo chuyên sâu về SOC, bao gồm phân tích log, sử dụng SIEM (Splunk/ELK), và Digital Forensics.",
    image: "https://picsum.photos/seed/cert2/600/400"
  },
  {
    slug: "google-cybersecurity-professional",
    title: "Google Cybersecurity Professional Certificate",
    issuer: "Coursera / Google",
    date: "2024-08-01",
    verification_url: "https://coursera.org",
    description: "Chương trình đào tạo 8 khóa học về Python, SQL, Linux, IDS, SIEM và quản lý rủi ro.",
    image: "https://picsum.photos/seed/cert3/600/400"
  }
];
